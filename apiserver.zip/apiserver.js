var express = require('express');
var bodyParser = require('body-parser');
var cons = require('consolidate');
var cookie = require('cookie');

var urlencodedParser = bodyParser.urlencoded({ extended: true });
var app = express();
app.use(bodyParser.json());

const { Gateway,Wallets } = require('fabric-network');
const path = require('path');
const fs = require('fs');

app.engine('html', cons.swig)
app.set('views', path.join(__dirname, 'views/templates'));
app.set('view engine', 'html');
// res.render("allcars",{ list:JSON.parse(result)});


// ###################################get from database##############################################
// ---------------------------------------login---------------------------------------------
app.get('/api/loginfront', function (req, res) {

    res.render('login');

});

app.get('/api/request', function (req, res) {

    res.render('request');

});
// ---------------------------------------login---------------------------------------------
// ------------------------------------registration---------------------------------------------
app.get('/api/registration', function (req, res) {

    res.render('registration');

});
// -----------------------------------rgistration---------------------------------------------
// ---------------------------get retailer logistic data ----------------------------------
app.get('/api/getRetailer/:UserId',urlencodedParser ,async function (req, res) {
        try {
    const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
    
            const walletPath = path.join(process.cwd(), 'wallet');
            const wallet = await Wallets.newFileSystemWallet(walletPath);
            console.log(`Wallet path: ${walletPath}`);
    
            const identity = await wallet.get('appUser');
            if (!identity) {
                console.log('An identity for the user "appUser" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }
      
            const gateway = new Gateway();
            await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
    
    
            const network = await gateway.getNetwork('mychannel');
    
    
            const contract = network.getContract('fabcar');
    
            const result = await contract.evaluateTransaction('login', req.params.UserId);
            
            const resi=JSON.parse(result);
            console.log(resi);
            console.log(resi.password);
            const pass=resi.password;
            const role=resi.role;
    
    
            res.status(200).json({response: result.toString()});
    } catch (error) {
            console.error(`Failed to evaluate transaction: ${error}`);
            res.status(500).json({error: error});
            process.exit(1);
        }
    });
// ---------------------------get logistic data-------------------------------------

// ---------------------------get warehouse data ----------------------------------
app.get('/api/getWarehouse/:UserId', async function (req, res) {
        try {
    const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
    
            const walletPath = path.join(process.cwd(), 'wallet');
            const wallet = await Wallets.newFileSystemWallet(walletPath);
            console.log(`Wallet path: ${walletPath}`);
    
            const identity = await wallet.get('appUser');
            if (!identity) {
                console.log('An identity for the user "appUser" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }
      
            const gateway = new Gateway();
            await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
    
    
            const network = await gateway.getNetwork('mychannel');
    
    
            const contract = network.getContract('fabcar');
    
            const result = await contract.evaluateTransaction('login', req.params.UserId);
            
            const resi=JSON.parse(result);
            console.log(resi);
            console.log(resi.password);
            const pass=resi.password;
            const role=resi.role;
    
    
            res.status(200).json({response: result.toString()});
    } catch (error) {
            console.error(`Failed to evaluate transaction: ${error}`);
            res.status(500).json({error: error});
            process.exit(1);
        }
    });
    // ---------------------------get warehouse data-------------------------------------
    
// --------------------------get login data----------------------------------------
app.post('/api/login/', urlencodedParser , async function (req, res) {
    try {
const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }
  
        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });


        const network = await gateway.getNetwork('mychannel');


        const contract = network.getContract('fabcar');

        const result = await contract.evaluateTransaction('login', req.body.UserId);
        
        const resi=JSON.parse(result);
        console.log(resi);
        console.log(resi.password);
        const pass=resi.password;
        const role=resi.role;
        const email=resi.userEmail;
        console.log(role);
        console.log(req.body.UserId);
        const UID=req.body.UserId;
        console.log(req.body.password);

        if(req.body.password==pass){
            console.log("dsadsa");
            var setCookie = cookie.serialize('role', role);
            
            if  (resi.role == "retailer") {
                res.render('request');
            } else if (resi.role == "manufacturer" || resi.role == "supplier") {
                res.render('adminview');
            }

            // sessionStorage.setItem("role",role);
            // sessionStorage.setItem("userID",UID);
            // sessionStorage.setItem("email", email);           
        }else{
            res.render('fail');
        }
} catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        res.status(500).json({error: error});
        process.exit(1);
    }
});
// ---------------------------get login data----------------------------------

// ---------------------------get Manufacture logistic data ----------------------------------
app.get('/api/getLogisticToManufacure', async function (req, res)  {
        try {
            const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
    
            const walletPath = path.join(process.cwd(), 'wallet');
            const wallet = await Wallets.newFileSystemWallet(walletPath);
            console.log(`Wallet path: ${walletPath}`);
    
            const identity = await wallet.get('appUser');
            if (!identity) {
                console.log('An identity for the user "appUser" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }
    
            const gateway = new Gateway();
            await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
    
    
            const network = await gateway.getNetwork('mychannel');
    
            const contract = network.getContract('fabcar');
    
            
            const result = await contract.evaluateTransaction('queryAllusers');
    
            const resi_count=JSON.parse(result);
            var count = Object.keys(resi_count).length;
            console.log(count);
    
     
        //     const resi=JSON.parse(result)[i];
            console.log(JSON.parse(result));

        res.render("test",{ list:JSON.parse(result)});
    
            // for(let i=0;i<count;i++){  
            //         const resi=JSON.parse(result)[i]["Record"]["logistic"];
            //         console.log(resi);
            // }
    
        // res.status(200).json({response: result.toString()});
            
    } catch (error) {
            console.error(`Failed to evaluate transaction: ${error}`);
            res.status(500).json({error: error});
            process.exit(1);
        }
    });
    // ---------------------------get logistic data------------------------------------- 
    app.get('/api/track', async function (req, res)  {
        try {
            const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
    
            const walletPath = path.join(process.cwd(), 'wallet');
            const wallet = await Wallets.newFileSystemWallet(walletPath);
            console.log(`Wallet path: ${walletPath}`);
    
            const identity = await wallet.get('appUser');
            if (!identity) {
                console.log('An identity for the user "appUser" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }
    
            const gateway = new Gateway();
            await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
    
    
            const network = await gateway.getNetwork('mychannel');
    
            const contract = network.getContract('fabcar');
    
            
            const result = await contract.evaluateTransaction('queryAllusers');
    
            const resi_count=JSON.parse(result);
            var count = Object.keys(resi_count).length;
            console.log(count);
    
     
        //     const resi=JSON.parse(result)[i];
            console.log(JSON.parse(result));

        res.render("track",{ list:JSON.parse(result)});
    
            // for(let i=0;i<count;i++){  
            //         const resi=JSON.parse(result)[i]["Record"]["logistic"];
            //         console.log(resi);
            // }
    
        // res.status(200).json({response: result.toString()});
            
    } catch (error) {
            console.error(`Failed to evaluate transaction: ${error}`);
            res.status(500).json({error: error});
            process.exit(1);
        }
    });

    app.get('/api/adminview', async function (req, res)  {
        try {
            const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
    
            const walletPath = path.join(process.cwd(), 'wallet');
            const wallet = await Wallets.newFileSystemWallet(walletPath);
            console.log(`Wallet path: ${walletPath}`);
    
            const identity = await wallet.get('appUser');
            if (!identity) {
                console.log('An identity for the user "appUser" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }
    
            const gateway = new Gateway();
            await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
    
    
            const network = await gateway.getNetwork('mychannel');
    
            const contract = network.getContract('fabcar');
    
            
            const result = await contract.evaluateTransaction('queryAllusers');
    
            const resi_count=JSON.parse(result);
            var count = Object.keys(resi_count).length;
            console.log(count);
    
     
        //     const resi=JSON.parse(result)[i];
            console.log(JSON.parse(result));

        res.render("adminview",{ list:JSON.parse(result)});
    
            // for(let i=0;i<count;i++){  
            //         const resi=JSON.parse(result)[i]["Record"]["logistic"];
            //         console.log(resi);
            // }
    
        // res.status(200).json({response: result.toString()});
            
    } catch (error) {
            console.error(`Failed to evaluate transaction: ${error}`);
            res.status(500).json({error: error});
            process.exit(1);
        }
    });

    app.get('/api/aprove', async function (req, res)  {
        try {
            const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
    
            const walletPath = path.join(process.cwd(), 'wallet');
            const wallet = await Wallets.newFileSystemWallet(walletPath);
            console.log(`Wallet path: ${walletPath}`);
    
            const identity = await wallet.get('appUser');
            if (!identity) {
                console.log('An identity for the user "appUser" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }
    
            const gateway = new Gateway();
            await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
    
    
            const network = await gateway.getNetwork('mychannel');
    
            const contract = network.getContract('fabcar');
    
            
            const result = await contract.evaluateTransaction('queryAllusers');
    
            const resi_count=JSON.parse(result);
            var count = Object.keys(resi_count).length;
            console.log(count);
    
     
        //     const resi=JSON.parse(result)[i];
            console.log(JSON.parse(result));

        res.render("aprove",{ list:JSON.parse(result)});
    
            // for(let i=0;i<count;i++){  
            //         const resi=JSON.parse(result)[i]["Record"]["logistic"];
            //         console.log(resi);
            // }
    
        // res.status(200).json({response: result.toString()});
            
    } catch (error) {
            console.error(`Failed to evaluate transaction: ${error}`);
            res.status(500).json({error: error});
            process.exit(1);
        }
    });
// ---------------------------get Supplier logistic data ----------------------------------
app.get('/api/getLogisticToSupplier', async function (req, res)  {
        try {
            const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
    
            const walletPath = path.join(process.cwd(), 'wallet');
            const wallet = await Wallets.newFileSystemWallet(walletPath);
            console.log(`Wallet path: ${walletPath}`);
    
            const identity = await wallet.get('appUser');
            if (!identity) {
                console.log('An identity for the user "appUser" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }
    
            const gateway = new Gateway();
            await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
    
    
            const network = await gateway.getNetwork('mychannel');
    
            const contract = network.getContract('fabcar');
    
            
            const result = await contract.evaluateTransaction('queryAllusers');
    
            const resi_count=JSON.parse(result);
            var count = Object.keys(resi_count).length;
            console.log(count);
    
     
            // const resi=JSON.parse(result)[i];
            // console.log(resi);
    
            for(let i=0;i<count;i++){  
                    const resi=JSON.parse(result)[i]["Record"];
                    console.log(resi);
            }
    
            res.status(200).json({response: result.toString()});
    } catch (error) {
            console.error(`Failed to evaluate transaction: ${error}`);
            res.status(500).json({error: error});
            process.exit(1);
        }
    });
    // ---------------------------get logistic data------------------------------------- 
    
    
// #######################################get from database##################################


app.post('/api/addcar/', urlencodedParser, async function (req, res) {
    try {
const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
        
        const network = await gateway.getNetwork('mychannel');

        const contract = network.getContract('fabcar');
        console.log('attmpt to fetch'); 
        console.log(req.toString()); 
        if(req.body.password==req.body.repassword){
            console.log('password match');  
            console.log(req.body.id);  
            console.log(req.body.role);  
            console.log(req.body.userEmail);  
            console.log(req.body.password);  
            console.log(req.body.logistic);  
            console.log(req.body.companyName);  
            console.log(req.body.companyAddress);  
            console.log(req.body.companyEmail); 
            console.log(req.body.phone);    
            await contract.submitTransaction('createCar', req.body.id, req.body.role, req.body.userEmail, req.body.password, req.body.logistic, req.body.companyName, req.body.companyAddress, req.body.companyEmail, req.body.phone);
            console.log('Transaction has been submitted');
            res.send('Transaction has been submitted');
        }else{
            console.log('password  didnt matched'); 
        }
// Disconnect from the gateway.
        await gateway.disconnect();
} catch (error) {
        console.error(`Failed to submit transaction: ${error}`);
        process.exit(1);
    }
})

// ###################################################################
app.post('/api/addlog/', urlencodedParser ,async function (req, res) {
        try {
    const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
    
            const walletPath = path.join(process.cwd(), 'wallet');
            const wallet = await Wallets.newFileSystemWallet(walletPath);
            console.log(`Wallet path: ${walletPath}`);
    
            const identity = await wallet.get('appUser');
            if (!identity) {
                console.log('An identity for the user "appUser" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }
    
            const gateway = new Gateway();
            await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
            
            const network = await gateway.getNetwork('mychannel');
    
            const contract = network.getContract('fabcar');
            console.log('Transaction has try');
            await contract.submitTransaction('addLogistic',req.body.userid, req.body.orderID, req.body.retailerid, req.body.product,req.body.quantity,req.body.status,req.body.supplierID);
            console.log('Transaction has been submitted');
            res.send('Transaction has been submitted');
    // Disconnect from the gateway.
            await gateway.disconnect();
    } catch (error) {
            console.error(`Failed to submit transaction: ${error}`);
            process.exit(1);
        }
    })
// #################################################################

app.post('/api/changeowner/:car_index',urlencodedParser ,async function (req, res) {
    try {
const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
// Create a new file system based wallet for managing identities.
        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }
  // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });

        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('mychannel'); 

        // Get the contract from the network.
        const contract = network.getContract('fabcar');
// Submit the specified transaction.
        // createCar transaction - requires 5 argument, ex: ('createCar', 'CAR12', 'Honda', 'Accord', 'Black', 'Tom')
        // changeCarOwner transaction - requires 2 args , ex: ('changeCarOwner', 'CAR10', 'Dave')
        await contract.submitTransaction('changeCarOwner', req.params.car_index, req.body.owner);
        console.log('Transaction has been submitted');
        res.send('Transaction has been submitted');
// Disconnect from the gateway.
        await gateway.disconnect();
} catch (error) {
        console.error(`Failed to submit transaction: ${error}`);
        process.exit(1);
    } 
})

// #################################################update status#########################
app.post('/api/UpdateStatus/', urlencodedParser ,async function (req, res) {
        try {
    const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
    // Create a new file system based wallet for managing identities.
            const walletPath = path.join(process.cwd(), 'wallet');
            const wallet = await Wallets.newFileSystemWallet(walletPath);
            console.log(`Wallet path: ${walletPath}`);
    
            // Check to see if we've already enrolled the user.
            const identity = await wallet.get('appUser');
            if (!identity) {
                console.log('An identity for the user "appUser" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }
      // Create a new gateway for connecting to our peer node.
            const gateway = new Gateway();
            await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
    
            // Get the network (channel) our contract is deployed to.
            const network = await gateway.getNetwork('mychannel'); 
    
            // Get the contract from the network.
            const contract = network.getContract('fabcar');
    // Submit the specified transaction.
            // createCar transaction - requires 5 argument, ex: ('createCar', 'CAR12', 'Honda', 'Accord', 'Black', 'Tom')
            // changeCarOwner transaction - requires 2 args , ex: ('changeCarOwner', 'CAR10', 'Dave')
            await contract.submitTransaction('UpdateStatus', req.body.UserId, req.body.OrderId,req.body.newStatus);
            console.log('Transaction has been submitted');
            res.send('Transaction has been submitted');
    // Disconnect from the gateway.
            await gateway.disconnect();
    } catch (error) {
            console.error(`Failed to submit transaction: ${error}`);
            process.exit(1);
        } 
    })
// ################################################update ststus#########################
app.listen(8080);