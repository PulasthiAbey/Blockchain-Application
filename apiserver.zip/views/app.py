from flask import Flask, render_template, request, redirect, session, g

from flask_mysqldb import MySQL

import os

app = Flask(__name__)

app.secret_key = os.urandom(24)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_PORT'] = 3306
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'company_db'

mysql=MySQL(app)

@app.route('/')
def home():
	return render_template("login.html")

@app.route('/index')
def index():
	return render_template("index.html")

@app.route("/registration")
def registration():
		return render_template("registration.html")

@app.route("/login")
def login():
	return render_template("login.html")

@app.route("/fail")
def fail():
	return render_template("fail.html")
	

@app.route("/success")
def success():
	return render_template("success.html")

@app.route("/blank")
def blank():
	return render_template("blank.html")

@app.route("/retailer")
def retailer():
	cur = mysql.connection.cursor()
	if cur.execute("SELECT user_id from retailer where user_id =%s",(g.user,))==1:
		return redirect("request")
	return redirect("login")

@app.route("/supplier")
def supplier():
	cur = mysql.connection.cursor()
	if cur.execute("SELECT user_id from supplier where user_id =%s",(g.user,))==1:
		return redirect("view")
	return redirect("login")

@app.route("/logistic")
def logistic():
	cur = mysql.connection.cursor()
	if cur.execute("SELECT user_id from logistic where user_id =%s",(g.user,))==1:
		return redirect("view")
	return redirect("login")

@app.route("/wherehouse")
def wherehouse():
	cur = mysql.connection.cursor()
	if cur.execute("SELECT user_id from wherehouse where user_id =%s",(g.user,))==1:
		return redirect("view")
	return redirect("login")

@app.route("/manufactory")
def manufactory():
	cur = mysql.connection.cursor()
	if cur.execute("SELECT user_id from manufactory where user_id =%s",(g.user,))==1:
		return redirect("adminview")
	return redirect("login")

@app.route("/request")
def reques():
	cur = mysql.connection.cursor()
	if cur.execute("SELECT user_id from retailer where user_id =%s",(g.user,))==1:
		role="Retailer"
		cur.execute("SELECT product_name from product ;")
		data =cur.fetchall()
		return render_template("request.html",data=data,role=role)
	return redirect("login")

@app.route("/track")
def track():
	cur = mysql.connection.cursor()
	if cur.execute("SELECT user_id from retailer where user_id =%s",(g.user,))==1:
		try:
			role="Retailer"
			user_id=g.user
			cur.execute("SELECT p.product_name,o.product_quantity,o.status from product as p inner join orders as o on o.product_id = p.product_id where o.user_id=%s order by o.order_id desc;",(user_id,))
			data=cur.fetchall()
			return render_template("track.html",data=data,role=role)
		except:
			return render_template("request.html")
	return redirect("login")

@app.route("/view")
def view():
	cur = mysql.connection.cursor()
	if cur.execute("SELECT user_id from supplier where user_id =%s",(g.user,))==1 or cur.execute("SELECT user_id from wherehouse where user_id =%s",(g.user,))==1 or cur.execute("SELECT user_id from logistic where user_id =%s",(g.user,))==1:
		try:
			user=g.user
			cur.execute("SELECT user_type from user where user_id=%s;",(user,))
			role=cur.fetchone()
			cur.execute("SELECT o.order_id,o.user_id,p.product_name,o.product_quantity,o.status from product as p inner join orders as o on o.product_id = p.product_id order by o.order_id desc;")
			data=cur.fetchall()
			return render_template("view.html",data=data,role=role[0])
		except:
			return render_template("view.html")
	return redirect("login")

@app.route("/viewform",methods=['GET','POST'])
def viewform():
	if request.method =='POST':
		cur = mysql.connection.cursor()
		if cur.execute("SELECT user_id from supplier where user_id =%s",(g.user,))==1 or cur.execute("SELECT user_id from wherehouse where user_id =%s",(g.user,))==1 or cur.execute("SELECT user_id from logistic where user_id =%s",(g.user,))==1:
			try:
				if 'Accept' in request.form:
					status='Aproved'
					order_id=request.form['order_id']
					cur.execute("UPDATE orders set status =%s where order_id=%s;",(status,order_id))
					return redirect("view")
				elif 'Reject' in request.form:
					status='Rejected'
					order_id=request.form['order_id']
					cur.execute("UPDATE orders set status =%s where order_id=%s;",(status,order_id))
					return redirect("view")

			except:
				return redirect("login")
		return redirect("login")

@app.route("/adminview")
def adminview():
	cur = mysql.connection.cursor()
	if cur.execute("SELECT user_id from manufactory where user_id =%s",(g.user,))==1:
		try:
			user=g.user
			cur.execute("SELECT user_type from user where user_id=%s;",(user,))
			role=cur.fetchone()
			cur.execute("SELECT o.order_id,o.user_id,p.product_name,o.product_quantity,o.status from product as p inner join orders as o on o.product_id = p.product_id order by o.order_id desc;")
			data=cur.fetchall()
			return render_template("adminview.html",data=data,role=role[0])
		except:
			return render_template("view.html")
	else:
		return redirect("login")

@app.route("/adminviewform",methods=['GET','POST'])
def adminviewform():
	if request.method =='POST':
		cur = mysql.connection.cursor()
		if cur.execute("SELECT user_id from manufactory where user_id =%s",(g.user,))==1:
			try:
				if 'Accept' in request.form:
					status='Aproved'
					order_id=request.form['order_id']
					cur.execute("UPDATE orders set status =%s where order_id=%s;",(status,order_id))
					return redirect("adminview")
				elif 'Reject' in request.form:
					status='Rejected'
					order_id=request.form['order_id']
					cur.execute("UPDATE orders set status =%s where order_id=%s;",(status,order_id))
					return redirect("adminview")

			except:
				return redirect("login")
		else:
			return redirect("login")

@app.route("/aprove")
def aprove():
	cur = mysql.connection.cursor()
	if cur.execute("SELECT user_id from manufactory where user_id =%s",(g.user,))==1:
		try:
			user=g.user
			cur.execute("SELECT user_type from user where user_id=%s;",(user,))
			role=cur.fetchone()
			cur.execute("SELECT product_id,product_name,company_name,product_size,product_validator from product where product_validator is null;")
			data=cur.fetchall()
			return render_template("aprove.html",data=data,role=role[0])
		except:
			return render_template("view.html")
	else:
		return redirect("login")


@app.route("/aproveform",methods=['GET','POST'])
def aproveform():
	if request.method =='POST':
		cur = mysql.connection.cursor()
		if cur.execute("SELECT user_id from manufactory where user_id =%s",(g.user,))==1:
			try:
				user_id=g.user
				product_id=request.form['product_id']
				cur.execute("UPDATE product set product_validator =%s where product_id=%s;",(user_id,product_id))
				return redirect("aprove")
			except:
				return redirect("aprove")
		return redirect("login")


@app.route("/requestform",methods=['GET','POST'])
def requestform():
	if request.method =='POST':
		cur = mysql.connection.cursor()
		if cur.execute("SELECT user_id from retailer where user_id =%s",(g.user,))==1:
			try:
				user_id=g.user
				product=request.form['product']
				cur.execute("SELECT product_id from product where product_name =%s limit 1",(product,))
				prodcut_id=cur.fetchall()
				quantity=request.form['quantity']
				status='Pending'
				cur.execute("INSERT INTO orders(product_id,product_quantity,user_id,status) values(%s,%s,%s,%s)",(prodcut_id,quantity,user_id,status))
				return render_template("order_success.html")
			except:
				return render_template("request.html")
		return redirect("login")


@app.route("/log", methods=['GET', 'POST'])
def log():
	if request.method == 'POST':
		session.pop('user',None)
		try:
			user_id = request.form['userid']
			password = request.form['password']

			cur = mysql.connection.cursor()
			row=cur.execute("SELECT user_id,user_password from user where user_id =%s and user_password =%s",(user_id,password))

			if row==1:
				session['user']=user_id = request.form['userid']
				if cur.execute("SELECT user_id from retailer where user_id =%s",(user_id,))==1:
					return redirect("retailer")
				elif cur.execute("SELECT user_id from supplier where user_id =%s",(user_id,))==1:
					return redirect("supplier")
				elif cur.execute("SELECT user_id from logistic where user_id =%s",(user_id,))==1:
					return redirect("logistic")
				elif cur.execute("SELECT user_id from wherehouse where user_id =%s",(user_id,))==1:
					return redirect("wherehouse")
				elif cur.execute("SELECT user_id from manufactory where user_id =%s",(user_id,))==1:
					return redirect("manufactory")
			else:
				return render_template("login.html",err="Invalid user id or password!")
			mysql.connection.commit()
			cur.close()
		except:
			return redirect("fail")
	else:
		return render_template("login.html",err="credential error")

@app.route("/adduser", methods=['GET', 'POST'])
def adduser():
	if request.method == "POST":
		try:
			details = request.form
			userid = details['userid']
			useremail = details['useremail']
			password = details['password']
			con_password = details['conpassword']
			user_type =details['user_type']
			com_name = details['com_name']
			com_address=details['com_address']
			com_email=details['com_email']
			com_tp=details['com_tp']
			com_mailbox=details['com_mailbox']

			if not(password == con_password):
				return render_template("registration.html",err="Password not match!")

			if not(userid.isnumeric()):
				return render_template("registration.html",err="Invalid user id or alredy registered user! eg: 101")

			cur = mysql.connection.cursor()

			if user_type =='retailer':
				cur.execute("INSERT INTO retailer(user_id) values(%s)",(userid,))
			elif user_type =='supplier':
				cur.execute("INSERT INTO supplier(user_id) values(%s)",(userid,))
			elif user_type =='logistic':
				cur.execute("INSERT INTO logistic(user_id) values(%s)",(userid,))
			elif user_type =='wherehouse':
				cur.execute("INSERT INTO wherehouse(user_id) values(%s)",(userid,))

			cur.execute("INSERT INTO user(user_id,user_email,user_password,user_type,company_name,company_address,company_email,company_telephone,company_mailbox) values(%s, %s, %s, %s,%s,%s,%s,%s,%s)",(userid,useremail,password,user_type,com_name,com_address,com_email,com_tp,com_mailbox))
			mysql.connection.commit()
			cur.close()
			return redirect("success")
		except:
			return render_template("registration.html",err="Invalid user id or alredy registered user! eg: 101")

@app.before_request
def before_request():
	g.user =None

	if 'user' in session:
		g.user = session['user']

@app.route("/dropsession")
def dropsession():
	session.pop('user',None)
	return redirect("login")

if __name__ == "__main__":
	app.run(debug=True)